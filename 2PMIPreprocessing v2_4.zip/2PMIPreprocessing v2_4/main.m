clc;
functiondir=cd;

addpath([functiondir '/SystemFunc']);
addpath([functiondir '/Enhancing']);
addpath([functiondir '/Denoising']);
addpath([functiondir '/Denoising/BM3D']);
addpath([functiondir '/Registration']);
addpath([functiondir '/ZProject']);
addpath([functiondir '/Fusion']);

run MainInterface.m;









