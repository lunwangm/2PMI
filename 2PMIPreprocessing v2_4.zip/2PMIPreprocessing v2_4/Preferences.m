function Preferences()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%name:Preferences.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%author:luyang
%date:20170220
%function:
%��Algorithm����������preference�������޸ġ�
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%Enhancing%%%%%%%%%%%%%%%%%%%%%%
%checkbox default value: 0~1
parmValue.EnhancingCheckboxValue = 0;
parmValue.EnhancingMenuValue = 1;

%Normalize
parmValue.EnhancingParm.SaturatedPCT = 0.003;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%Denoising%%%%%%%%%%%%%%%%%%%%%%
%checkbox default value: 0~1
parmValue.DenoisingCheckboxValue = 0;
parmValue.DenoisingMenuValue = 2;


%3-D median filtering
parmValue.DenoisingParm.radiusX = 1;
parmValue.DenoisingParm.radiusY = 1;
parmValue.DenoisingParm.radiusT = 1;


%VST BM3D filtering

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%Registration%%%%%%%%%%%%%%%%%%%%%%
%checkbox default value: 0~1
parmValue.RegistrationCheckboxValue = 1;
parmValue.RegistrationMenuValue = 1;

%IntensityBasedRegistration
parmValue.RegistrationParm.modality = 'monomodal'; %'multimodal' or 'monomodal'
parmValue.RegistrationParm.maxIteration = 200;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%ImgFusion%%%%%%%%%%%%%%%%%%%%%%
%checkbox default value: 0~1
parmValue.ImgFusionCheckboxValue = 1;
parmValue.ImgFusionMenuValue = 1;

%Avg ZProject
% parmValue.ImgFusionParm.ds = 3; %���򴰿ڰ뾶
% parmValue.ImgFusionParm.Ds = 5; %�������ڰ뾶
% parmValue.ImgFusionParm.h = 10; %��˹����ƽ������

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%MovingAverage%%%%%%%%%%%%%%%%%%%%%%
parmValue.MovingAverageValue = 1;
parmValue.NumberOfMovingAverage = 3;%�������趨ΪΪ���ڵ���2������ ���򱨴�



%�������Ϊ.mat��ʽ,���������޸�
save('Preferences.mat','parmValue');






