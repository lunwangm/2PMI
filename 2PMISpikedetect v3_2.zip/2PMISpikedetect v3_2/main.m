functiondir=cd;

addpath([functiondir '/SystemFunc']);
addpath([functiondir '/Roi']);
addpath([functiondir '/Spikedetect']);
addpath([functiondir '/ImageProcess']);
addpath([functiondir '/Annotation']);
addpath([functiondir '/Prediction']);
addpath([functiondir '/Prediction/libsvm/matlab']);
addpath([functiondir '/Prediction/libsvm/matlab-implement']);

run MainInterface.m;












