clear;



% filePath = './new/new all SLY.xlsx';
filePath = './new/new all.xlsx';



inputData = xlsread(filePath);
[m, n] = size(inputData);


result = [];
for i = 3:16
    
    temp_r = corrcoef(inputData(:, 2), abs(inputData(:, i)));
    result = [result, temp_r(1, 2)];
    
end

xx = 1;

