clear;


filePath = './data/all8.xlsx';
inputData = xlsread(filePath);


%label data set
abandonedDataIndex = (inputData(:, 2) == -1);
labels = inputData(~abandonedDataIndex, 2);
[dataRows, ~] = size(labels);


%training data set
multiFeature = inputData(~abandonedDataIndex, 4:end);


myLibsvmMdl = load('./myLibsvmMdl.mat');
myLibsvmMdl = myLibsvmMdl.myLibsvmMdl;
[predictLabel, accuracy] = svmpredict(labels, multiFeature, myLibsvmMdl); 



