%% wiAndv_example
% faruto
% last modified by 2011.07.07
%% a little clean work
tic;
clear;
clc;
close all;
format compact;
%% load data
load heart_scale.mat;
%% -wi example

data = heart_scale_inst;
label = heart_scale_label;

% without -wi parameter
model = svmtrain(label,data,'-c 1');
% ClassResult.m������libsvm-3.1-[FarutoUltimate3.1Mcode]����������
% libsvm-3.1-[FarutoUltimate3.1Mcode]���������ص�ַ��
% http://www.matlabsky.com/thread-17936-1-1.html
CR = ClassResult(label, data, model);

% with -wi parameter
modelwi = svmtrain(label,data,'-c 1 -w1 2 -w-1 0.5');
CR = ClassResult(label, data, modelwi);
%% -v example
accuracy = svmtrain(heart_scale_label,heart_scale_inst,'-s 0 -v 5')

mse = svmtrain(heart_scale_label,heart_scale_inst,'-s 3 -v 5')

%% record time
toc;